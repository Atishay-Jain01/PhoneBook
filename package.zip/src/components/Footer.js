import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div className="text-center">
        &copy; all rights reserved by Aryan Raj Singh Rathore 2025
      </div>
    )
  }
}
