import React from 'react'

const Header = () => {
  return (
    <div>
      <div className="alert alert-primary">
        <div className="container">
          <h1><i class="bi bi-journal-arrow-down"></i>
          PhoneBook App</h1>
        </div>
      </div>
    </div>
    
  )
}

export default Header